# Week 2 - Data Cleaning and Preprocessing

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
n = 500

df = pd.DataFrame({
    "shipment_id": [f"SHP{i:05d}" for i in range(n)],
    "carrier": rng.choice(["Carrier A", "Carrier B", "Carrier C"], n),
    "distance_km": rng.gamma(2.2, 180, n).clip(10, 1200),
    "weight_kg": rng.gamma(2.0, 8, n).clip(0.5, 100),
    "transport_cost": rng.normal(2500, 900, n).clip(150, None),
})

# Simulate missing values
missing_idx = rng.choice(n, 15, replace=False)
df.loc[missing_idx, "weight_kg"] = np.nan

print("Missing-value percentage:")
print((df.isna().mean() * 100).sort_values(ascending=False))

# Median imputation
df["weight_kg"] = df["weight_kg"].fillna(df["weight_kg"].median())

# IQR outlier detection
q1 = df["transport_cost"].quantile(.25)
q3 = df["transport_cost"].quantile(.75)
iqr = q3 - q1
lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr

outliers = df[(df["transport_cost"] < lower) | (df["transport_cost"] > upper)]

print(f"Potential transport-cost outliers: {len(outliers)}")
print(f"Cleaned rows: {len(df)}")
