# Week 3 - Advanced EDA and Visualization

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

OUTPUT = Path("outputs")
OUTPUT.mkdir(exist_ok=True)

rng = np.random.default_rng(42)
n = 500

df = pd.DataFrame({
    "date": rng.choice(pd.date_range("2026-01-01", periods=180), n),
    "distance_km": rng.gamma(2.2, 180, n).clip(10, 1200),
    "weight_kg": rng.gamma(2.0, 8, n).clip(.5, 100),
    "carrier": rng.choice(["Carrier A", "Carrier B", "Carrier C"], n),
    "service_level": rng.choice(["Standard", "Express"], n, p=[.75, .25]),
})

df["transport_cost"] = (
    450 + df["distance_km"] * 4.2 + df["weight_kg"] * 22
    + rng.normal(0, 220, n)
).clip(150, None)

df["delivery_days"] = (
    1.2 + df["distance_km"] / 300 + df["weight_kg"] / 70
    + np.where(df["service_level"].eq("Express"), -.8, 0)
    + rng.normal(0, .55, n)
).clip(.5, 12)

print(df.describe())
print("\nCorrelation matrix:")
print(df[["distance_km","weight_kg","transport_cost","delivery_days"]].corr())

daily = df.groupby("date")["delivery_days"].mean().sort_index()
plt.figure(figsize=(8, 4.5))
daily.rolling(7, min_periods=1).mean().plot()
plt.title("7-Day Rolling Average Delivery Time")
plt.xlabel("Date")
plt.ylabel("Average delivery days")
plt.tight_layout()
plt.savefig(OUTPUT / "delivery_time_trend.png", dpi=160)
plt.close()

plt.figure(figsize=(7, 4.5))
df.groupby("carrier")["transport_cost"].mean().plot(kind="bar")
plt.title("Average Transport Cost by Carrier")
plt.xlabel("Carrier")
plt.ylabel("Average cost")
plt.tight_layout()
plt.savefig(OUTPUT / "carrier_cost_comparison.png", dpi=160)
plt.close()

plt.figure(figsize=(7, 4.5))
plt.scatter(df["distance_km"], df["delivery_days"], alpha=.45)
plt.title("Distance vs Delivery Time")
plt.xlabel("Distance (km)")
plt.ylabel("Delivery days")
plt.tight_layout()
plt.savefig(OUTPUT / "distance_vs_delivery_time.png", dpi=160)
plt.close()

print("Charts saved in outputs/")
