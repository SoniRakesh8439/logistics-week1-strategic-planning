# Week 4 - Predictive Modeling and Optimization

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

rng = np.random.default_rng(42)
n = 500

df = pd.DataFrame({
    "distance_km": rng.gamma(2.2, 180, n).clip(10, 1200),
    "weight_kg": rng.gamma(2.0, 8, n).clip(.5, 100),
    "carrier": rng.choice(["Carrier A", "Carrier B", "Carrier C"], n),
    "service_level": rng.choice(["Standard", "Express"], n, p=[.75, .25]),
})

carrier_effect = {"Carrier A": .2, "Carrier B": .5, "Carrier C": -.1}

df["delivery_days"] = (
    1.2 + df["distance_km"] / 300 + df["weight_kg"] / 70
    + df["carrier"].map(carrier_effect)
    + np.where(df["service_level"].eq("Express"), -.8, 0)
    + rng.normal(0, .55, n)
).clip(.5, 12)

X = df[["distance_km", "weight_kg", "carrier", "service_level"]]
y = df["delivery_days"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=.20, random_state=42
)

pre = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore"),
     ["carrier", "service_level"])
], remainder="passthrough")

models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(
        n_estimators=250, random_state=42, min_samples_leaf=3
    ),
}

for name, estimator in models.items():
    model = Pipeline([("preprocess", pre), ("model", estimator)])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)

    mae = mean_absolute_error(y_test, pred)
    rmse = np.sqrt(mean_squared_error(y_test, pred))
    r2 = r2_score(y_test, pred)

    print(f"\n{name}")
    print(f"MAE : {mae:.3f}")
    print(f"RMSE: {rmse:.3f}")
    print(f"R2  : {r2:.3f}")

# Optimization concept:
# Minimize transportation cost + predicted late-delivery penalty,
# subject to carrier capacity and service-level constraints.
