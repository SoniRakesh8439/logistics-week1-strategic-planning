# Logistics Data Analyst Internship Project

Four-week logistics analytics project covering:
1. Strategic planning and KPI definition
2. Data cleaning and preprocessing
3. Exploratory data analysis and visualization
4. Predictive modeling and optimization

The shipment data used by the scripts is simulated for educational purposes.

## Run
```bash
pip install -r requirements.txt
python week1/strategic_planning.py
python week2/data_cleaning_preprocessing.py
python week3/advanced_eda_visualization.py
python week4/predictive_modeling_optimization.py
```

## KPIs
- On-Time Delivery Rate
- Average Delivery Time
- Late Delivery Rate
- Cost per Shipment
- Cost per Kilometer
