# Week 1 - Strategic Planning and Data Exploration

KPIS = {
    "On-Time Delivery Rate": "On-time shipments / total delivered shipments",
    "Average Delivery Time": "Mean delivery duration",
    "Late Delivery Rate": "Late shipments / total shipments",
    "Cost per Shipment": "Transportation cost / shipment count",
    "Cost per Kilometer": "Transportation cost / distance",
}

roadmap = [
    "Business understanding",
    "Data collection",
    "Data validation",
    "Data cleaning",
    "Exploratory data analysis",
    "Feature engineering",
    "Predictive modeling",
    "Optimization",
    "Monitoring",
]

print("Logistics KPIs")
for k, v in KPIS.items():
    print(f"{k}: {v}")

print("\nAnalytics roadmap")
for step in roadmap:
    print("-", step)
