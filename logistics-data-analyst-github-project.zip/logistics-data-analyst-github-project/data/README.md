# Data

The internship task allows a hypothetical logistics dataset. The Python scripts generate simulated shipment data so the project is reproducible without private company information.

Typical fields include shipment ID, dates, warehouse, destination, carrier, service level, distance, weight, transportation cost and delivery duration.
